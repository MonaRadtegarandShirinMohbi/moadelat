# Security Policy

## Supported Versions

Due to time constraints, only the most recent version will be updated with security 
patches. 

## Reporting a Vulnerability

If you find a vulnerability, please notify me via email at camerongurban@gmail.com.
