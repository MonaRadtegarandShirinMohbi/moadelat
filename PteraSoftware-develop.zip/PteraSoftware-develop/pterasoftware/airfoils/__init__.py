"""This module doesn't import anything. It is only here to make the airfoils
directory a package.
"""
